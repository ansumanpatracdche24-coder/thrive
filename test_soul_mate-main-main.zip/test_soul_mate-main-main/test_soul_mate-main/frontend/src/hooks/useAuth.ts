// Re-export everything from the AuthContext
export { useAuth } from '@/contexts/AuthContext';